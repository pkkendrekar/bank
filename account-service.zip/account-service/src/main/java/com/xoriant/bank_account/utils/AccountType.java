package com.xoriant.bank_account.utils;

public enum AccountType {
SAVING,CURRENT
}
//0 1