package com.xoriant.bank_account.service;

import java.util.List;
import java.util.Set;

import com.xoriant.bank_account.entities.SavingAccount;

//import com.xoriant.productservice.model.Product;

public interface SavingAccountService {
	 
	//List<SavingAccount>findAllSavingAccount();
	 List<SavingAccount> findAll();
		
	 
	
}

