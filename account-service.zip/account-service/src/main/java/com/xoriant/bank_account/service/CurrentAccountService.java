package com.xoriant.bank_account.service;

import java.util.List;

import com.xoriant.bank_account.entities.Account;

//import com.xoriant.productservice.model.Product;

public interface CurrentAccountService {
	 
	List<?> findAll();
 
}

