package com.xoriant.bank_account.entities;

import javax.persistence.Entity;

@Entity
public class SavingAccount extends Account{
	
	private double dailyLimitAmount;
	private int dailyLimitNoofTransaction;

	public SavingAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SavingAccount(double dailyLimitAmount, int dailyLimitNoofTransaction) {
		super();
		this.dailyLimitAmount = dailyLimitAmount;
		this.dailyLimitNoofTransaction = dailyLimitNoofTransaction;
	}

	public double getDailyLimitAmount() {
		return dailyLimitAmount;
	}

	public void setDailyLimitAmount(double dailyLimitAmount) {
		this.dailyLimitAmount = dailyLimitAmount;
	}

	public int getDailyLimitNoofTransaction() {
		return dailyLimitNoofTransaction;
	}

	public void setDailyLimitNoofTransaction(int dailyLimitNoofTransaction) {
		this.dailyLimitNoofTransaction = dailyLimitNoofTransaction;
	}

	@Override
	public String toString() {
		return "SavingAccount [dailyLimitAmount=" + dailyLimitAmount + ", dailyLimitNoofTransaction="
				+ dailyLimitNoofTransaction + ", accountNo=" + accountNo + ", accountHolderName=" + accountHolderName
				+ ", accounttype=" + accounttype + ", openDate=" + openDate + ", accountStatus=" + accountStatus
				+ ", balance=" + balance + ", customerId=" + customerId + ", transaction=" + transaction
				+ ", getDailyLimitAmount()=" + getDailyLimitAmount() + ", getDailyLimitNoofTransaction()="
				+ getDailyLimitNoofTransaction() + ", getAccountNo()=" + getAccountNo() + ", getAccountHolderName()="
				+ getAccountHolderName() + ", getAccounttype()=" + getAccounttype() + ", getOpenDate()=" + getOpenDate()
				+ ", isAccountStatus()=" + isAccountStatus() + ", getBalance()=" + getBalance() + ", getCustomerId()="
				+ getCustomerId() + ", getTransaction()=" + getTransaction() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	 

}
