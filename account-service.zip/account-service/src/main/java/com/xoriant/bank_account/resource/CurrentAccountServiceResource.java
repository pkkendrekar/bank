package com.xoriant.bank_account.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xoriant.bank_account.service.CurrentAccountService;

@RestController
@RequestMapping("api/current")
public class CurrentAccountServiceResource {
@Autowired
private CurrentAccountService accountService;

@GetMapping()
public List<?>getAll(){
	return accountService.findAll();
}
}
