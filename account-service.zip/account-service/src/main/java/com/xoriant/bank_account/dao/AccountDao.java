package com.xoriant.bank_account.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.xoriant.bank_account.entities.Account;
import com.xoriant.bank_account.entities.CurrentAccount;

public interface AccountDao extends JpaRepository<Account,Long> {
//
//	@Query(value="select * from account  ",nativeQuery=true)
//	List<Account> findAll();
//	
	
}
