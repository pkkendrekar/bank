package com.xoriant.bank_account;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.xoriant.bank_account.service.CurrentAccountServiceImpl;
import com.xoriant.bank_account.service.SavingAccountServiceImpl;


@SpringBootApplication
public class AccountServiceApplication {

	public static void main(String[] args) {
//	ApplicationContext ac=SpringApplication.run(AccountServiceApplication.class, args);
//SavingAccountServiceImpl accountServiceImpl=ac.getBean(SavingAccountServiceImpl.class);
//		SavingAccountServiceImpl savingaccountServiceImpl=ac.getBean(SavingAccountServiceImpl.class);
		SpringApplication.run(AccountServiceApplication.class, args);
	}

}
