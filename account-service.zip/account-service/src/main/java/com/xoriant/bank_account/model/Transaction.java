package com.xoriant.bank_account.model;

import java.time.LocalDate;

import com.xoriant.bank_account.entities.Account;
import com.xoriant.bank_account.utils.TransactionType;

public class Transaction {
	private long transactionId;
	private LocalDate transactionDate;
	private TransactionType transactiontype;
	private double transactionAmount;
	private String transactionDescription;
	private long fromAccount;
	private long toAccount;
//private Account fromAccount;
//private Account toAccount;

	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Transaction(long transactionId, LocalDate transactionDate, TransactionType transactiontype,
			double transactionAmount, String transactionDescription, long fromAccount, long toAccount) {
		super();
		this.transactionId = transactionId;
		this.transactionDate = transactionDate;
		this.transactiontype = transactiontype;
		this.transactionAmount = transactionAmount;
		this.transactionDescription = transactionDescription;
		this.fromAccount = fromAccount;
		this.toAccount = toAccount;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public LocalDate getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}

	public TransactionType getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(TransactionType transactiontype) {
		this.transactiontype = transactiontype;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getTransactionDescription() {
		return transactionDescription;
	}

	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}

	public long getFromAccount() {
		return fromAccount;
	}

	public void setFromAccount(long fromAccount) {
		this.fromAccount = fromAccount;
	}

	public long getToAccount() {
		return toAccount;
	}

	public void setToAccount(long toAccount) {
		this.toAccount = toAccount;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate
				+ ", transactiontype=" + transactiontype + ", transactionAmount=" + transactionAmount
				+ ", transactionDescription=" + transactionDescription + ", fromAccount=" + fromAccount + ", toAccount="
				+ toAccount + "]";
	}

}
