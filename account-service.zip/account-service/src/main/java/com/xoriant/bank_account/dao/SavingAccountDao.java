package com.xoriant.bank_account.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.xoriant.bank_account.entities.SavingAccount;

public interface SavingAccountDao extends JpaRepository<SavingAccount,Long> {

	
//	@Query(value="select * from saving_account  ",nativeQuery=true)
	//List<SavingAccount> findAllSavingAccount();

//	 List<SavingAccount> findAll();
//	
	
}
