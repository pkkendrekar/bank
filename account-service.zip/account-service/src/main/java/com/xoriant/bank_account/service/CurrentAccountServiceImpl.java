package com.xoriant.bank_account.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.bank_account.dao.AccountDao;
import com.xoriant.bank_account.dao.CurrentAccountDao;
import com.xoriant.bank_account.entities.Account;
import com.xoriant.bank_account.entities.CurrentAccount;

@Service
@Transactional
public class CurrentAccountServiceImpl implements CurrentAccountService {

	
	@Autowired
	private CurrentAccountDao currentaccountdao;
	@Override
	public 	List<CurrentAccount> findAll()
	{
		return currentaccountdao.findAll();
	}	
	
	
}
//List<Account>findAllcurrent_account();
