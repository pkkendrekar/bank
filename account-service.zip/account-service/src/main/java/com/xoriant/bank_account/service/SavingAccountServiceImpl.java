package com.xoriant.bank_account.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.bank_account.dao.SavingAccountDao;
import com.xoriant.bank_account.entities.SavingAccount;

@Service
@Transactional
public class SavingAccountServiceImpl implements SavingAccountService {

	@Autowired
	private SavingAccountDao savingaccountdao;

	@Override
	public    List<SavingAccount> findAll()
	 {
		return savingaccountdao.findAll();
	}
}
