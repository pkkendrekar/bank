package com.xoriant.bank_account.entities;

import javax.persistence.Entity;

@Entity
public class CurrentAccount extends Account{
	private double minBalance;
	private String companyName;

	public CurrentAccount() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CurrentAccount(double minBalance, String companyName) {
		super();
		this.minBalance = minBalance;
		this.companyName = companyName;
	}

	public double getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(double minBalance) {
		this.minBalance = minBalance;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	@Override
	public String toString() {
		return "CurrentAccount [minBalance=" + minBalance + ", companyName=" + companyName + ", accountNo=" + accountNo
				+ ", accountHolderName=" + accountHolderName + ", accounttype=" + accounttype + ", openDate=" + openDate
				+ ", accountStatus=" + accountStatus + ", balance=" + balance + ", customerId=" + customerId
				+ ", transaction=" + transaction + ", getMinBalance()=" + getMinBalance() + ", getCompanyName()="
				+ getCompanyName() + ", getAccountNo()=" + getAccountNo() + ", getAccountHolderName()="
				+ getAccountHolderName() + ", getAccounttype()=" + getAccounttype() + ", getOpenDate()=" + getOpenDate()
				+ ", isAccountStatus()=" + isAccountStatus() + ", getBalance()=" + getBalance() + ", getCustomerId()="
				+ getCustomerId() + ", getTransaction()=" + getTransaction() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	

}
