package com.xoriant.bank_account.utils;

public enum TransactionType {
SAVING,DEPOSIT,TRANSFER
}
