package com.xoriant.bank_customer.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xoriant.bank_customer.service.CustomerService;

@RestController
@RequestMapping("/api/customer")
public class CustomerResource {
	@Autowired
	private CustomerService  customerservice;
	
	
	
	@GetMapping
	public List<?> findAllCustomer() {
		return customerservice.findAllCustomer();

	}
}
