package com.xoriant.bank_customer.entities;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

import com.xoriant.bank_customer.utils.Gender;
@Entity
@Table(name="Personal_Info")
@Inheritance(strategy=InheritanceType.JOINED)
public class PersonalInfo  {
	@Id
	@GeneratedValue
	protected int personalInfoId;
	
	@OneToOne
	@JoinColumn(name="user_id")
protected User user;
	
@NotBlank(message = "Name is required")
@Length(min = 3, max = 15, message = "Invalid len of Name")
//@Column(length = 20,name = "p_name")
protected String name;

//@DateTimeFormat(pattern = "dd-MM-yyyy")
protected LocalDate birthDate;

private Gender gender;
@Column(unique = true,name = "email")
protected String emailId;

//@Column(unique = true,name = "address")
@OneToOne
protected Address address;


@NotBlank(message = "Mobile number is required")
@Length( max = 10, message = "Invalid Mobile number")
@Column(length = 10,name = "Mobile_number")
protected long mobNo;


public PersonalInfo() {
	super();
	// TODO Auto-generated constructor stub
}


public PersonalInfo(int personalInfoId, User user,
		@NotBlank(message = "Name is required") @Length(min = 3, max = 15, message = "Invalid len of Name") String name,
		LocalDate birthDate, Gender gender, String emailId, Address address,
		@NotBlank(message = "Mobile number is required") @Length(max = 10, message = "Invalid Mobile number") long mobNo) {
	super();
	this.personalInfoId = personalInfoId;
	this.user = user;
	this.name = name;
	this.birthDate = birthDate;
	this.gender = gender;
	this.emailId = emailId;
	this.address = address;
	this.mobNo = mobNo;
}


public int getPersonalInfoId() {
	return personalInfoId;
}


public void setPersonalInfoId(int personalInfoId) {
	this.personalInfoId = personalInfoId;
}


public User getUser() {
	return user;
}


public void setUser(User user) {
	this.user = user;
}


public String getName() {
	return name;
}


public void setName(String name) {
	this.name = name;
}


public LocalDate getBirthDate() {
	return birthDate;
}


public void setBirthDate(LocalDate birthDate) {
	this.birthDate = birthDate;
}


public Gender getGender() {
	return gender;
}


public void setGender(Gender gender) {
	this.gender = gender;
}


public String getEmailId() {
	return emailId;
}


public void setEmailId(String emailId) {
	this.emailId = emailId;
}


public Address getAddress() {
	return address;
}


public void setAddress(Address address) {
	this.address = address;
}


public long getMobNo() {
	return mobNo;
}


public void setMobNo(long mobNo) {
	this.mobNo = mobNo;
}


@Override
public String toString() {
	return "PersonalInfo [personalInfoId=" + personalInfoId + ", user=" + user + ", name=" + name + ", birthDate="
			+ birthDate + ", gender=" + gender + ", emailId=" + emailId + ", address=" + address + ", mobNo=" + mobNo
			+ "]";
}


 }