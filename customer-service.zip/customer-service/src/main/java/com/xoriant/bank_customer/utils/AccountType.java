package com.xoriant.bank_customer.utils;

public enum AccountType {
SAVING,CURRENT
}
