package com.xoriant.bank_customer.utils;

public enum TransactionType {
SAVING,DEPOSIT,TRANSFER
}
