package com.xoriant.bank_customer.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.xoriant.bank_customer.utils.Role;

@Entity
@Table(name="user")
public class User {
	@Id //PK
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	@Column(name="user_id")
	private Integer userid;
	@NotBlank(message = "Name is required")
	@Length(min = 3, max = 15, message = "Invalid len of Name")
	//@Column(length = 20,name = "U_NAME")
	
	private String username;
	@Column(length = 20,nullable = false,name="PASS")
	@JsonIgnore
	private String userpassword;
	//@Enumerated(EnumType.STRING)
	@Enumerated(EnumType.ORDINAL)
	private Role role;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(Integer userid,
			@NotBlank(message = "Name is required") @Length(min = 3, max = 15, message = "Invalid len of Name") String username,
			String userpassword, Role role) {
		super();
		this.userid = userid;
		this.username = username;
		this.userpassword = userpassword;
		this.role = role;
	}
	public Integer getUserid() {
		return userid;
	}
	public void setUserid(Integer userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "User [userid=" + userid + ", username=" + username + ", userpassword=" + userpassword + ", role=" + role
				+ "]";
	}
	
	
	
	
	
	
}