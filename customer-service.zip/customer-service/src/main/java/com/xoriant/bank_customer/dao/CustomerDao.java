package com.xoriant.bank_customer.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.xoriant.bank_customer.entities.Customer;

public interface CustomerDao extends JpaRepository<Customer,Integer> {
//	@Query("select p from User p where p.name=:c")
//	List<User> findByname(@Param("c") String name);
@Query(value="select * from Customer ",nativeQuery=true)
List<Customer>findAllCustomer();
}
//findByname(name)