package com.xoriant.bank_customer.utils;

public enum Gender {
MALE,FEMALE
}
