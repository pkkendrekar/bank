package com.xoriant.bank_customer.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name="address")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="address_Id")
	private int addressId;
	@Column(name="flat_No")
	private int flatNo;
	@NotBlank(message = "Name is required")
	@Length(min = 3, max = 15, message = "Invalid length of flat Name")
	@Column(length = 20,name = "flat_name")
	private String flatName;
	private String streetName;
	private String cityName;
	private String state;
	
	@NotBlank(message = "Pincode can not be blank")
	private int pincode;

	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Address(int addressId, int flatNo,
			@NotBlank(message = "Name is required") @Length(min = 3, max = 15, message = "Invalid length of flat Name") String flatName,
			String streetName, String cityName, String state,
			@NotBlank(message = "Pincode can not be blank") int pincode) {
		super();
		this.addressId = addressId;
		this.flatNo = flatNo;
		this.flatName = flatName;
		this.streetName = streetName;
		this.cityName = cityName;
		this.state = state;
		this.pincode = pincode;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public String getFlatName() {
		return flatName;
	}

	public void setFlatName(String flatName) {
		this.flatName = flatName;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", flatNo=" + flatNo + ", flatName=" + flatName + ", streetName="
				+ streetName + ", cityName=" + cityName + ", state=" + state + ", pincode=" + pincode + "]";
	}

}