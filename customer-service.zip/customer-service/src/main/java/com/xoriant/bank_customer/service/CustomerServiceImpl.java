package com.xoriant.bank_customer.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.bank_customer.dao.CustomerDao;
import com.xoriant.bank_customer.entities.Customer;
@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	
	@Autowired
	private CustomerDao customerdao;
public 	List<Customer>findAllCustomer(){
	return customerdao.findAll();
}
}
