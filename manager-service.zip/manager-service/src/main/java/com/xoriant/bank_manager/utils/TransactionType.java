package com.xoriant.bank_manager.utils;

public enum TransactionType {
SAVING,DEPOSIT,TRANSFER
}
