package com.xoriant.bank_manager.utils;

public enum Role {
	CUSTOMER,MANAGER
}
