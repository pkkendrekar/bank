package com.xoriant.bank_manager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.xoriant.bank_customer.service.CustomerServiceImpl;

@SpringBootApplication
public class CustomerServiceApplication {

	public static void main(String[] args) {
		ApplicationContext ac=SpringApplication.run(CustomerServiceApplication.class, args);
		CustomerServiceImpl customerServiceImpl=ac.getBean(CustomerServiceImpl.class);
	}

}
