package com.xoriant.bank_manager.utils;

public enum Gender {
MALE,FEMALE
}
