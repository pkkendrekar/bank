package com.xoriant.bank_manager.utils;

public enum AccountType {
SAVING,CURRENT
}
