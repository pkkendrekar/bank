package com.xoriant.bank_customer.service;

import java.util.List;

import com.xoriant.bank_customer.entities.Customer;
import com.xoriant.bank_customer.entities.User;

//import com.xoriant.productservice.model.Product;

public interface CustomerService {
	//List<?> findAllcustomers();

	//List<?> findAllCustomers();

	//List<?> findAllProducts();
	//List<User> displayAllUsers(String name); 
	List<Customer>findAllCustomer();
	
}

