package com.xoriant.bank_customer.entities;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;

import com.xoriant.bank_customer.model.Account;
import com.xoriant.bank_manager.utils.Gender;
@Entity
public class Customer extends PersonalInfo {
	@Transient
//	@OneToMany
	private List<Account>accounts;
	
	@OneToOne
	@JoinColumn(name="branch_id")
	private Branch branch;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int personalInfoId, User user,
			@NotBlank(message = "Name is required") @Length(min = 3, max = 15, message = "Invalid len of Name") String name,
			LocalDate birthDate, Gender gender, String emailId, Address address,
			@NotBlank(message = "Mobile number is required") @Length(max = 10, message = "Invalid Mobile number") long mobNo) {
		super(personalInfoId, user, name, birthDate, gender, emailId, address, mobNo);
		// TODO Auto-generated constructor stub
	}

	public Customer(List<Account> accounts, Branch branch) {
		super();
		this.accounts = accounts;
		this.branch = branch;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	@Override
	public String toString() {
		return "Customer [accounts=" + accounts + ", branch=" + branch + "]";
	}

}