package com.xoriant.bank_customer.model;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.xoriant.bank_customer.entities.Customer;
import com.xoriant.bank_manager.utils.AccountType;

public class Account {
protected long accountNo;
protected String accountHolderName;
protected AccountType accounttype;

@DateTimeFormat(pattern = "dd-MM-yyyy")
protected LocalDate openDate;

protected boolean accountStatus;
protected double balance;

protected List<Transaction>transactions;

 private Customer customer;

public Account() {
	super();
	// TODO Auto-generated constructor stub
}

public Account(long accountNo, String accountHolderName, AccountType accounttype, LocalDate openDate,
		boolean accountStatus, double balance, List<Transaction> transactions, Customer customer) {
	super();
	this.accountNo = accountNo;
	this.accountHolderName = accountHolderName;
	this.accounttype = accounttype;
	this.openDate = openDate;
	this.accountStatus = accountStatus;
	this.balance = balance;
	this.transactions = transactions;
	this.customer = customer;
}

public long getAccountNo() {
	return accountNo;
}

public void setAccountNo(long accountNo) {
	this.accountNo = accountNo;
}

public String getAccountHolderName() {
	return accountHolderName;
}

public void setAccountHolderName(String accountHolderName) {
	this.accountHolderName = accountHolderName;
}

public AccountType getAccounttype() {
	return accounttype;
}

public void setAccounttype(AccountType accounttype) {
	this.accounttype = accounttype;
}

public LocalDate getOpenDate() {
	return openDate;
}

public void setOpenDate(LocalDate openDate) {
	this.openDate = openDate;
}

public boolean isAccountStatus() {
	return accountStatus;
}

public void setAccountStatus(boolean accountStatus) {
	this.accountStatus = accountStatus;
}

public double getBalance() {
	return balance;
}

public void setBalance(double balance) {
	this.balance = balance;
}

public List<Transaction> getTransactions() {
	return transactions;
}

public void setTransactions(List<Transaction> transactions) {
	this.transactions = transactions;
}

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}

@Override
public String toString() {
	return "Account [accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", accounttype="
			+ accounttype + ", openDate=" + openDate + ", accountStatus=" + accountStatus + ", balance=" + balance
			+ ", customer=" + customer + "]";
}
 
 
 
}