package com.xoriant.bank_customer.model;

import java.time.LocalDate;

import com.xoriant.bank_manager.utils.TransactionType;

public class Transaction {
private long transactionId;
private LocalDate transactionDate;
private  TransactionType transactiontype;
private Account fromAccount;
private Account toAccount;
public Transaction() {
	super();
	// TODO Auto-generated constructor stub
}
public Transaction(long transactionId, LocalDate transactionDate, TransactionType transactiontype, Account fromAccount,
		Account toAccount) {
	super();
	this.transactionId = transactionId;
	this.transactionDate = transactionDate;
	this.transactiontype = transactiontype;
	this.fromAccount = fromAccount;
	this.toAccount = toAccount;
}
public long getTransactionId() {
	return transactionId;
}
public void setTransactionId(long transactionId) {
	this.transactionId = transactionId;
}
public LocalDate getTransactionDate() {
	return transactionDate;
}
public void setTransactionDate(LocalDate transactionDate) {
	this.transactionDate = transactionDate;
}
public TransactionType getTransactiontype() {
	return transactiontype;
}
public void setTransactiontype(TransactionType transactiontype) {
	this.transactiontype = transactiontype;
}
public Account getFromAccount() {
	return fromAccount;
}
public void setFromAccount(Account fromAccount) {
	this.fromAccount = fromAccount;
}
public Account getToAccount() {
	return toAccount;
}
public void setToAccount(Account toAccount) {
	this.toAccount = toAccount;
}
@Override
public String toString() {
	return "Transaction [transactionId=" + transactionId + ", transactionDate=" + transactionDate + ", transactiontype="
			+ transactiontype + ", fromAccount=" + fromAccount + ", toAccount=" + toAccount + "]";
}



}
