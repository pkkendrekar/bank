package com.xoriant.bank_transaction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;


import com.xoriant.bank_transaction.service.TransactionServiceImpl;


@SpringBootApplication
public class TransactionServiceApplication {

	public static void main(String[] args) {
//	ApplicationContext ac=SpringApplication.run(AccountServiceApplication.class, args);
//SavingAccountServiceImpl accountServiceImpl=ac.getBean(SavingAccountServiceImpl.class);
//		SavingAccountServiceImpl savingaccountServiceImpl=ac.getBean(SavingAccountServiceImpl.class);
		SpringApplication.run(TransactionServiceApplication.class, args);
	}

}
