package com.xoriant.bank_transaction.service;

import java.util.List;

import com.xoriant.bank_transaction.entities.Transaction;

//import com.xoriant.productservice.model.Product;

public interface TransactionService {
	 
	//List<SavingAccount>findAllSavingAccount();
	 List<Transaction> findAll();
		
	 
	
}

