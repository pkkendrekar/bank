package com.xoriant.bank_transaction.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;


@Table(name="branch")
public class Branch {
	@Id //PK
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="branch_id")
private Integer id;
	@NotBlank(message = "Branch Name is required")
	@Length(min = 3, max = 15, message = "Invalid branch name")
	@Column(length = 20,name = "branch_name")
private String branchName;
	@NotBlank(message = "Branch Address is required")
	@Length(min = 3, max = 15, message = "Invalid branch address")
	@Column(length = 20,name = "branch_address")
private String address;
	@NotBlank(message = " IFSC code can not be blanck")
	@Length(min=15, max = 15, message = "Invalid IFSC Code")
	@Column(length = 20,name = "IFSC_code")
private  String ifscCode;
	
	private long micrNo;

	public Branch() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Branch(Integer id,
			@NotBlank(message = "Branch Name is required") @Length(min = 3, max = 15, message = "Invalid branch name") String branchName,
			@NotBlank(message = "Branch Address is required") @Length(min = 3, max = 15, message = "Invalid branch address") String address,
			@NotBlank(message = " IFSC code can not be blanck") @Length(min = 15, max = 15, message = "Invalid IFSC Code") String ifscCode,
			long micrNo) {
		super();
		this.id = id;
		this.branchName = branchName;
		this.address = address;
		this.ifscCode = ifscCode;
		this.micrNo = micrNo;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public long getMicrNo() {
		return micrNo;
	}

	public void setMicrNo(long micrNo) {
		this.micrNo = micrNo;
	}

	@Override
	public String toString() {
		return "Branch [id=" + id + ", branchName=" + branchName + ", address=" + address + ", ifscCode=" + ifscCode
				+ ", micrNo=" + micrNo + "]";
	}
}