package com.xoriant.bank_transaction.utils;

public enum AccountType {
SAVING,CURRENT
}
//0 1