package com.xoriant.bank_transaction.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xoriant.bank_transaction.dao.TransactionDao;

import com.xoriant.bank_transaction.entities.Transaction;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionDao transactiondao;

	@Override
	public    List<Transaction> findAll()
	 {
		return transactiondao.findAll();
	}
}
