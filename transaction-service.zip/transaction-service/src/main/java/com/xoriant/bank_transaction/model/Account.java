package com.xoriant.bank_transaction.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

import com.xoriant.bank_transaction.entities.Transaction;
import com.xoriant.bank_transaction.utils.AccountType;


public class Account {
	@Id // PK
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	protected long accountNo;

	protected String accountHolderName;

	@Enumerated(EnumType.ORDINAL)
	protected AccountType accounttype;

	@DateTimeFormat(pattern = "dd-MM-yyyy")
	protected LocalDate openDate;

	protected boolean accountStatus;
	protected double balance;

	
	// private Customer customer;
	protected Customer customer;

	//@Transient
	protected List<Transaction> transaction;

	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(long accountNo, String accountHolderName, AccountType accounttype, LocalDate openDate,
			boolean accountStatus, double balance, Customer customer, List<Transaction> transaction) {
		super();
		this.accountNo = accountNo;
		this.accountHolderName = accountHolderName;
		this.accounttype = accounttype;
		this.openDate = openDate;
		this.accountStatus = accountStatus;
		this.balance = balance;
		this.customer = customer;
		this.transaction = transaction;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public AccountType getAccounttype() {
		return accounttype;
	}

	public void setAccounttype(AccountType accounttype) {
		this.accounttype = accounttype;
	}

	public LocalDate getOpenDate() {
		return openDate;
	}

	public void setOpenDate(LocalDate openDate) {
		this.openDate = openDate;
	}

	public boolean isAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(boolean accountStatus) {
		this.accountStatus = accountStatus;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Transaction> getTransaction() {
		return transaction;
	}

	public void setTransaction(List<Transaction> transaction) {
		this.transaction = transaction;
	}
	

	}