package com.xoriant.bank_transaction.model;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Transient;
import javax.validation.constraints.NotBlank;

import org.hibernate.validator.constraints.Length;



public class Customer  {
	//@Transient
//	@OneToMany
	private List<Account>accounts;
	
//	@OneToOne
//	@JoinColumn(name="branch_id")
	private Branch branch;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(List<com.xoriant.bank_transaction.model.Account> accounts, Branch branch) {
		super();
		this.accounts = accounts;
		this.branch = branch;
	}

	public List<Account> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}
}
	