package com.xoriant.bank_transaction.utils;

public enum TransactionType {
SAVING,DEPOSIT,TRANSFER
}
